//Ahsan Abbasi and Fahim Bokhari

var bubbles = []; //initializes an array to be used later



//creating literal object to be iterated ove

var oval = {
  x:0,
  speed:5
};
  

var mySound;
var bg;
var canvas;

//preload function loads the sound that is playing in the background

function preload() {
  mySound = loadSound('assets/wuTang.mp3');
}

// seeting volume and loading image to canvas

function setup() { // setup
  mySound.amp(1);
  mySound.loop();
  bg = loadImage('assets/wuTangClan.jpg'); //Loads image that was saved onto assets folder
  canvas = createCanvas(700,525); //creates canvas as the same size as background image
  canvas = createCanvas(700,525);

 for (var i = 0; i < 1; i++) {  //for loop that iterates over a new constructor functions
    bubbles[i] = new newball(); //creates new constructor functions correlating to the index of the array
  }

}
 
 function draw() { //draw functionsthat give the color
  background(bg)
  

  stroke(125);
  strokeWeight(2);
  fill(255, 0,0);
  ellipse(oval.x,  240, 50, 50);  //creates the position of the ellipse with the value being called from the literal oval object

  
  stroke(125);
  strokeWeight(2);
  fill(255, 0,0);
  ellipse(this.x,  this.y, 100, 100); //Same process as line 42 this time with the use of the constructor
                                      //function parameters
  
  if (oval.x > width)  { // conditionals that set the bound for the ball movement
        oval.speed=-5;
    }
  else if(oval.x<0){
    oval.speed=5
  }
  
  oval.x=oval.x+oval.speed
  
   for (var i = 0; i < bubbles.length; i++) { //for loop that iterates through length of ball array
    bubbles[i].move();
    bubbles[i].display(); //displays the second ball
  }

  }
  function newball() { //Calls the newball functio
  this.x = width/2;
  this.y = 0;
  this.speed=5;
 
  this.display = function() {
     stroke(125);
  strokeWeight(2);
  fill(255, 0,0);
  ellipse(this.x,  this.y, 50, 50); //Ellipse based on the parameters
  
  }
 
  this.move = function() {
    this.y = this.y + this.speed;
      if (this.y > height)  {
        this.speed=-5;
    }
  else if (this.y < 0){
    this.speed=5;
  }
  //if the ball goes down it will come right back up
  
  }
}